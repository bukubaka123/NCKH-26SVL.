# Đưa trang lên Google và kết nối bộ thiết bị

## 1. Đưa trang lên Google (Firebase Hosting, miễn phí)
1. Vào console.firebase.google.com, chọn Add project, đặt tên (ví dụ `tutruong-vl12`).
2. Cài Node.js, rồi chạy trong thư mục `web`:
   ```
   npm i -g firebase-tools
   firebase login
   firebase deploy --only hosting --project tutruong-vl12
   ```
3. Mở địa chỉ `https://tutruong-vl12.web.app` (lệnh deploy in ra địa chỉ này).

Không dùng Google Sites hoặc Drive: khung nhúng của chúng thường chặn USB và mạng nội bộ.

## 2. Nạp code cho ESP32
1. Arduino IDE: cài board "esp32 by Espressif" và thư viện "WebSockets" (Markus Sattler).
2. Mở `esp32/TuTruong_ESP32/TuTruong_ESP32.ino`, chọn ESP32 Dev Module, nạp code.
3. Mặc định `TEST_MODE 1` gửi số liệu giả để thử kết nối. Khi đã nối cảm biến, sửa `readB()` và `readF()`, đặt `TEST_MODE 0`.

Dữ liệu mỗi dòng/tin nhắn: `{"Bx":1.2,"By":40.5,"Bz":-0.3,"F":2.1}` (B tính bằng mT, F tính bằng mN).

## 3. Kết nối
- **USB**: dùng Chrome hoặc Edge trên máy tính, mở trang trên Google, chọn "USB (Web Serial)", bấm Kết nối, chọn cổng COM của ESP32.
- **Wi-Fi (nên dùng)**: nối Wi-Fi `TuTruong-Lab` (mật khẩu `12345678`), mở `http://192.168.4.1` (trang do chính ESP32 phát), chọn "Wi-Fi (WebSocket)" rồi Kết nối. Cách này không cần Internet. Mở file `index.html` trực tiếp trên máy (địa chỉ `192.168.4.1:81`) cũng được.
- **Wi-Fi từ trang trên Google**: trình duyệt chặn trang https gọi vào `ws://` của ESP32. Trong Chrome, bấm biểu tượng bên trái địa chỉ, vào Cài đặt trang web, đặt "Nội dung không an toàn" thành Cho phép, rồi nhập `192.168.4.1:81`. Hãy mở sẵn trang trước khi chuyển sang Wi-Fi của ESP32, vì lúc đó máy không còn Internet.
